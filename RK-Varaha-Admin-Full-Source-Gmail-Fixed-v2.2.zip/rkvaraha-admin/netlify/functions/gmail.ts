import { getStore } from '@netlify/blobs';
import type { Config, Context } from '@netlify/functions';

type DashboardUser = { id: string; email?: string };
type Membership = { role: string; active: boolean };
type TokenRecord = {
  access_token: string;
  refresh_token: string;
  expires_at: number;
  scope?: string;
  token_type?: string;
  email?: string;
  connected_at: string;
};
type StateRecord = { uid: string; returnOrigin: string; expiresAt: number };

const SUPABASE_URL = 'https://puishgbbxlxatkjejfke.supabase.co';
const SUPABASE_KEY = 'sb_publishable_VTCfIIf7wGgEBafBWiyFtQ_e_xOdcoa';
const GMAIL_API = 'https://gmail.googleapis.com/gmail/v1/users/me';
const encoder = new TextEncoder();
const decoder = new TextDecoder();

function env(name: string) {
  return Netlify.env.get(name)?.trim() || '';
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff',
    },
  });
}

function apiError(message: string, status = 400) {
  return json({ error: message }, status);
}

function missingConfiguration() {
  return ['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET', 'GMAIL_TOKEN_KEY'].filter((key) => !env(key));
}

function allowedOrigins() {
  const values = [
    'https://admin.rkvaraha.com',
    'https://rkvaraha-admin.netlify.app',
    ...env('GMAIL_ALLOWED_ORIGINS').split(',').map((value) => value.trim()),
  ].filter(Boolean);
  return new Set(values.map((value) => new URL(value).origin));
}

function requestOrigin(req: Request) {
  const origin = new URL(req.url).origin;
  if (!allowedOrigins().has(origin)) throw new Error('This dashboard origin is not allowed for Gmail OAuth.');
  return origin;
}

function redirectUri(origin: string) {
  return env('GMAIL_REDIRECT_URI') || `${origin}/api/gmail/callback`;
}

function bearer(req: Request) {
  const value = req.headers.get('authorization') || '';
  return value.startsWith('Bearer ') ? value.slice(7).trim() : '';
}

async function requireAdmin(req: Request) {
  const token = bearer(req);
  if (!token) throw Object.assign(new Error('Sign in again to continue.'), { status: 401 });

  const userResponse = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SUPABASE_KEY, authorization: `Bearer ${token}` },
  });
  if (!userResponse.ok) throw Object.assign(new Error('Your session has expired. Sign in again.'), { status: 401 });
  const user = (await userResponse.json()) as DashboardUser;

  const memberResponse = await fetch(
    `${SUPABASE_URL}/rest/v1/dashboard_users?user_id=eq.${encodeURIComponent(user.id)}&select=role,active&limit=1`,
    { headers: { apikey: SUPABASE_KEY, authorization: `Bearer ${token}`, accept: 'application/json' } },
  );
  if (!memberResponse.ok) throw Object.assign(new Error('Workspace access could not be verified.'), { status: 403 });
  const membership = ((await memberResponse.json()) as Membership[])[0];
  if (!membership?.active || !['owner', 'admin'].includes(membership.role)) {
    throw Object.assign(new Error('Owner or administrator access is required.'), { status: 403 });
  }
  return user;
}

function bytesToBase64Url(bytes: Uint8Array) {
  let binary = '';
  for (let index = 0; index < bytes.length; index += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(index, index + 0x8000));
  }
  return btoa(binary).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/g, '');
}

function base64UrlToBytes(value: string) {
  const padded = value.replaceAll('-', '+').replaceAll('_', '/') + '='.repeat((4 - (value.length % 4)) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

async function hmacKey() {
  return crypto.subtle.importKey('raw', encoder.encode(env('GMAIL_TOKEN_KEY')), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
}

async function signState(payload: Record<string, unknown>) {
  const encoded = bytesToBase64Url(encoder.encode(JSON.stringify(payload)));
  const signature = await crypto.subtle.sign('HMAC', await hmacKey(), encoder.encode(encoded));
  return `${encoded}.${bytesToBase64Url(new Uint8Array(signature))}`;
}

async function verifyState(value: string) {
  const [encoded, signature, extra] = value.split('.');
  if (!encoded || !signature || extra) throw new Error('The Gmail connection request is invalid.');
  const valid = await crypto.subtle.verify('HMAC', await hmacKey(), base64UrlToBytes(signature), encoder.encode(encoded));
  if (!valid) throw new Error('The Gmail connection request is invalid.');
  return JSON.parse(decoder.decode(base64UrlToBytes(encoded))) as { nonce: string; exp: number };
}

async function encryptionKey() {
  const digest = await crypto.subtle.digest('SHA-256', encoder.encode(env('GMAIL_TOKEN_KEY')));
  return crypto.subtle.importKey('raw', digest, 'AES-GCM', false, ['encrypt', 'decrypt']);
}

async function encrypt(value: TokenRecord) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await encryptionKey(), encoder.encode(JSON.stringify(value)));
  return { version: 1, iv: bytesToBase64Url(iv), data: bytesToBase64Url(new Uint8Array(encrypted)) };
}

async function decrypt(value: { version: number; iv: string; data: string }) {
  if (value?.version !== 1) throw new Error('The saved Gmail connection is not supported. Reconnect Gmail.');
  const plain = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: base64UrlToBytes(value.iv) },
    await encryptionKey(),
    base64UrlToBytes(value.data),
  );
  return JSON.parse(decoder.decode(plain)) as TokenRecord;
}

const tokenStore = () => getStore({ name: 'rkvaraha-gmail-tokens', consistency: 'strong' });
const stateStore = () => getStore({ name: 'rkvaraha-gmail-oauth-state', consistency: 'strong' });
const tokenKey = (uid: string) => `user/${uid}`;

async function readTokens(uid: string) {
  const saved = await tokenStore().get(tokenKey(uid), { type: 'json' }) as { version: number; iv: string; data: string } | null;
  return saved ? decrypt(saved) : null;
}

async function writeTokens(uid: string, tokens: TokenRecord) {
  await tokenStore().setJSON(tokenKey(uid), await encrypt(tokens));
}

async function googleToken(params: URLSearchParams) {
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: params,
  });
  const text = await response.text();
  let result: Record<string, unknown> = {};
  try { result = JSON.parse(text); } catch { /* Google returned a non-JSON error. */ }
  if (!response.ok) throw new Error(String(result.error_description || result.error || 'Google rejected the token request.'));
  return result as { access_token: string; refresh_token?: string; expires_in?: number; scope?: string; token_type?: string };
}

async function accessToken(uid: string) {
  const saved = await readTokens(uid);
  if (!saved) throw Object.assign(new Error('Connect Gmail before using this page.'), { status: 409 });
  if (saved.expires_at > Date.now() + 60_000) return { accessToken: saved.access_token, saved };
  if (!saved.refresh_token) throw Object.assign(new Error('Reconnect Gmail to refresh access.'), { status: 409 });

  const refreshed = await googleToken(new URLSearchParams({
    client_id: env('GOOGLE_CLIENT_ID'),
    client_secret: env('GOOGLE_CLIENT_SECRET'),
    refresh_token: saved.refresh_token,
    grant_type: 'refresh_token',
  }));
  const next: TokenRecord = {
    ...saved,
    access_token: refreshed.access_token,
    expires_at: Date.now() + Number(refreshed.expires_in || 3600) * 1000,
    scope: refreshed.scope || saved.scope,
    token_type: refreshed.token_type || saved.token_type,
  };
  await writeTokens(uid, next);
  return { accessToken: next.access_token, saved: next };
}

async function gmailFetch(uid: string, path: string, init: RequestInit = {}) {
  const { accessToken } = await accessToken(uid);
  const response = await fetch(`${GMAIL_API}${path}`, {
    ...init,
    headers: { ...init.headers, authorization: `Bearer ${accessToken}` },
  });
  if (!response.ok) {
    const text = await response.text();
    let message = `Gmail returned HTTP ${response.status}.`;
    try { message = JSON.parse(text)?.error?.message || message; } catch { /* Keep the safe HTTP message. */ }
    throw Object.assign(new Error(message), { status: response.status === 401 ? 409 : 502 });
  }
  return response;
}

function header(headers: Array<{ name: string; value: string }> = [], name: string) {
  return headers.find((item) => item.name.toLowerCase() === name.toLowerCase())?.value || '';
}

function decodeGmailBody(data = '') {
  if (!data) return '';
  return decoder.decode(base64UrlToBytes(data)).slice(0, 100_000);
}

function findBody(part: any): string {
  if (!part) return '';
  if (part.mimeType === 'text/plain' && part.body?.data) return decodeGmailBody(part.body.data);
  for (const child of part.parts || []) {
    const value = findBody(child);
    if (value) return value;
  }
  if (part.mimeType === 'text/html' && part.body?.data) {
    return decodeGmailBody(part.body.data).replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  }
  return part.body?.data ? decodeGmailBody(part.body.data) : '';
}

async function status(req: Request, user: DashboardUser) {
  const origin = requestOrigin(req);
  const missing = missingConfiguration();
  if (missing.length) return json({ configured: false, connected: false, missing, redirectUri: redirectUri(origin) });
  try {
    const saved = await readTokens(user.id);
    return json({ configured: true, connected: Boolean(saved), email: saved?.email || null, redirectUri: redirectUri(origin) });
  } catch {
    return json({ configured: true, connected: false, reconnect: true, redirectUri: redirectUri(origin) });
  }
}

async function connect(req: Request, user: DashboardUser) {
  const missing = missingConfiguration();
  if (missing.length) return apiError(`Missing Netlify environment variables: ${missing.join(', ')}`, 503);
  const returnOrigin = requestOrigin(req);
  const nonce = bytesToBase64Url(crypto.getRandomValues(new Uint8Array(24)));
  const expiresAt = Date.now() + 10 * 60_000;
  await stateStore().setJSON(`state/${nonce}`, { uid: user.id, returnOrigin, expiresAt } satisfies StateRecord);
  const state = await signState({ nonce, exp: expiresAt });
  const params = new URLSearchParams({
    client_id: env('GOOGLE_CLIENT_ID'),
    redirect_uri: redirectUri(returnOrigin),
    response_type: 'code',
    access_type: 'offline',
    prompt: 'consent',
    include_granted_scopes: 'true',
    scope: 'openid email https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/gmail.send',
    state,
  });
  return json({ url: `https://accounts.google.com/o/oauth2/v2/auth?${params}` });
}

async function callback(req: Request) {
  const url = new URL(req.url);
  const stateValue = url.searchParams.get('state') || '';
  const state = await verifyState(stateValue);
  if (!state.nonce || state.exp < Date.now()) throw new Error('The Gmail connection request expired. Start again.');
  const key = `state/${state.nonce}`;
  const record = await stateStore().get(key, { type: 'json' }) as StateRecord | null;
  if (!record || record.expiresAt < Date.now()) throw new Error('The Gmail connection request expired. Start again.');
  await stateStore().delete(key);

  const destination = new URL('/', record.returnOrigin);
  destination.hash = 'gmail';
  if (url.searchParams.get('error')) {
    destination.searchParams.set('gmail', 'denied');
    return Response.redirect(destination, 302);
  }
  const code = url.searchParams.get('code');
  if (!code) throw new Error('Google did not return an authorization code.');
  const exchanged = await googleToken(new URLSearchParams({
    code,
    client_id: env('GOOGLE_CLIENT_ID'),
    client_secret: env('GOOGLE_CLIENT_SECRET'),
    redirect_uri: redirectUri(record.returnOrigin),
    grant_type: 'authorization_code',
  }));
  if (!exchanged.refresh_token) throw new Error('Google did not return a refresh token. Remove RK Varaha access in your Google account and reconnect.');
  const profileResponse = await fetch(`${GMAIL_API}/profile`, { headers: { authorization: `Bearer ${exchanged.access_token}` } });
  const profile = profileResponse.ok ? await profileResponse.json() as { emailAddress?: string } : {};
  await writeTokens(record.uid, {
    access_token: exchanged.access_token,
    refresh_token: exchanged.refresh_token,
    expires_at: Date.now() + Number(exchanged.expires_in || 3600) * 1000,
    scope: exchanged.scope,
    token_type: exchanged.token_type,
    email: profile.emailAddress,
    connected_at: new Date().toISOString(),
  });
  destination.searchParams.set('gmail', 'connected');
  return Response.redirect(destination, 302);
}

async function messages(req: Request, user: DashboardUser) {
  const url = new URL(req.url);
  const params = new URLSearchParams({ maxResults: '20' });
  const query = (url.searchParams.get('q') || '').trim().slice(0, 300);
  const pageToken = (url.searchParams.get('pageToken') || '').trim().slice(0, 500);
  if (query) params.set('q', query);
  if (pageToken) params.set('pageToken', pageToken);
  const list = await (await gmailFetch(user.id, `/messages?${params}`)).json() as { messages?: Array<{ id: string }>; nextPageToken?: string; resultSizeEstimate?: number };
  const rows = await Promise.all((list.messages || []).map(async ({ id }) => {
    const meta = await (await gmailFetch(user.id, `/messages/${encodeURIComponent(id)}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=To&metadataHeaders=Date`)).json() as any;
    const headers = meta.payload?.headers || [];
    return { id, threadId: meta.threadId, subject: header(headers, 'Subject') || '(No subject)', from: header(headers, 'From'), to: header(headers, 'To'), date: header(headers, 'Date'), snippet: meta.snippet || '' };
  }));
  return json({ messages: rows, nextPageToken: list.nextPageToken || null, resultSizeEstimate: list.resultSizeEstimate || 0 });
}

async function message(req: Request, user: DashboardUser, context: Context) {
  const id = context.params.id || '';
  if (!/^[A-Za-z0-9_-]+$/.test(id)) return apiError('Invalid Gmail message ID.');
  const detail = await (await gmailFetch(user.id, `/messages/${encodeURIComponent(id)}?format=full`)).json() as any;
  const headers = detail.payload?.headers || [];
  return json({ id, subject: header(headers, 'Subject') || '(No subject)', from: header(headers, 'From'), to: header(headers, 'To'), date: header(headers, 'Date'), snippet: detail.snippet || '', body: findBody(detail.payload) });
}

async function send(req: Request, user: DashboardUser) {
  if (req.method !== 'POST') return apiError('Method not allowed.', 405);
  const body = await req.json().catch(() => null) as { to?: string; subject?: string; body?: string } | null;
  const to = body?.to?.trim() || '';
  const subject = body?.subject?.trim() || '';
  const content = body?.body?.trim() || '';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to) || to.length > 254) return apiError('Enter one valid recipient email address.');
  if (!subject || subject.length > 500) return apiError('Enter a subject up to 500 characters.');
  if (!content || content.length > 50_000) return apiError('Enter a message up to 50,000 characters.');
  const mime = [`To: ${to}`, `Subject: ${subject.replace(/[\r\n]+/g, ' ')}`, 'MIME-Version: 1.0', 'Content-Type: text/plain; charset=UTF-8', '', content].join('\r\n');
  const raw = bytesToBase64Url(encoder.encode(mime));
  const result = await (await gmailFetch(user.id, '/messages/send', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ raw }),
  })).json() as { id: string; threadId: string };
  return json({ sent: true, id: result.id, threadId: result.threadId });
}

async function disconnect(user: DashboardUser) {
  const saved = await readTokens(user.id);
  if (saved?.access_token) {
    await fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(saved.refresh_token || saved.access_token)}`, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
    }).catch(() => undefined);
  }
  await tokenStore().delete(tokenKey(user.id));
  return json({ disconnected: true });
}

export default async (req: Request, context: Context) => {
  try {
    const path = new URL(req.url).pathname.replace(/\/$/, '');
    if (path === '/api/gmail/callback') return await callback(req);
    const user = await requireAdmin(req);
    if (path === '/api/gmail/status' && req.method === 'GET') return await status(req, user);
    if (path === '/api/gmail/connect' && req.method === 'POST') return await connect(req, user);
    if (path === '/api/gmail/messages' && req.method === 'GET') return await messages(req, user);
    if (path.startsWith('/api/gmail/message/') && req.method === 'GET') return await message(req, user, context);
    if (path === '/api/gmail/send') return await send(req, user);
    if (path === '/api/gmail/disconnect' && req.method === 'POST') return await disconnect(user);
    return apiError('Gmail route not found.', 404);
  } catch (error) {
    const status = Number((error as { status?: number })?.status) || 500;
    const message = error instanceof Error ? error.message : 'The Gmail service failed.';
    console.error('Gmail function error:', message);
    return apiError(status >= 500 ? 'The Gmail service could not complete this request.' : message, status);
  }
};

export const config: Config = {
  path: [
    '/api/gmail/status',
    '/api/gmail/connect',
    '/api/gmail/callback',
    '/api/gmail/messages',
    '/api/gmail/message/:id',
    '/api/gmail/send',
    '/api/gmail/disconnect',
  ],
};
