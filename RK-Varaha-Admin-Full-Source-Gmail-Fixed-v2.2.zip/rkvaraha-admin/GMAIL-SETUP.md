# Gmail integration setup

This release contains the real Netlify Functions under `netlify/functions/`. Deploy the **repository root** through GitHub or the Netlify CLI. A manual ZIP containing only `dist/` cannot deploy the Gmail API routes.

## 1. Secure the Google OAuth client

The earlier client secret was visible in a screenshot. Delete or rotate that secret in Google Cloud before using this release.

Enable the Gmail API in the same Google Cloud project. Configure the OAuth consent screen and, while the app is in Testing, add the company mailbox as a test user.

For the Web application OAuth client, add:

- Authorized JavaScript origin: `https://admin.rkvaraha.com`
- Authorized JavaScript origin: `https://rkvaraha-admin.netlify.app`
- Authorized redirect URI: `https://admin.rkvaraha.com/api/gmail/callback`

The redirect URI must match exactly, including `https`, the hostname, and `/api/gmail/callback`.

## 2. Add Netlify environment variables

Open the existing `rkvaraha-admin` project in Netlify, then go to **Project configuration → Environment variables**. Add:

| Variable | Value |
|---|---|
| `GOOGLE_CLIENT_ID` | Web OAuth client ID from Google Cloud |
| `GOOGLE_CLIENT_SECRET` | Newly rotated client secret |
| `GMAIL_TOKEN_KEY` | A random secret of at least 32 characters |
| `GMAIL_REDIRECT_URI` | `https://admin.rkvaraha.com/api/gmail/callback` |
| `GMAIL_ALLOWED_ORIGINS` | `https://admin.rkvaraha.com,https://rkvaraha-admin.netlify.app` |

Generate `GMAIL_TOKEN_KEY` locally with `openssl rand -hex 32`, or use a password manager's random generator. Do not reuse a password.

Mark `GOOGLE_CLIENT_SECRET` and `GMAIL_TOKEN_KEY` as secret values. Apply them to Functions/Runtime and Production. Do not put them in GitHub, `netlify.toml`, browser JavaScript, or screenshots.

## 3. Deploy the full repository

Netlify settings are already included:

- Build command: `npm run build`
- Publish directory: `dist`
- Functions directory: `netlify/functions`
- Node: 22

After adding the environment variables, trigger a fresh production deploy. Sign in to the dashboard as the owner/admin, open **Gmail**, and choose **Connect Gmail**.

## Security behavior

- Every Gmail API request requires a valid Supabase dashboard session.
- Only active `owner` and `admin` roles can use Gmail.
- Google refresh tokens are encrypted before storage in site-scoped Netlify Blobs.
- OAuth state is signed, expires after ten minutes, and is single-use.
- The client rejects HTML responses instead of trying to parse them as JSON, so the previous `Unexpected token '<'` message is replaced by an actionable server-route error.

Google dashboard sign-in through Supabase is separate from Gmail mailbox access. Supabase login uses the Supabase callback; this Gmail integration uses `/api/gmail/callback`.
