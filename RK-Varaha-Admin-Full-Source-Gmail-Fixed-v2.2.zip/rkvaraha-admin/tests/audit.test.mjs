import test from 'node:test';
import assert from 'node:assert/strict';
import {auditDetails} from '../public/ui.js';
import {createApi} from '../public/api.js';
test('audit empty deltas give an explicit explanation, never blank details',()=>{
 for(const changes of [{},null,'{}','broken'])assert.match(auditDetails({actor_name:'System / integration',action:'update',entity:'enquiries',changes}),/no tracked field-level change/);
});
test('audit changes preserve false and zero and escape untrusted values',()=>{
 const html=auditDetails({actor_name:'<img src=x onerror=alert(1)>',changes:{active:{from:true,to:false},count:{from:1,to:0},status:{from:'new',to:'<script>alert(1)</script>'}}});
 assert.match(html,/No/);assert.match(html,/>0</);assert.doesNotMatch(html,/<script>|<img/);assert.match(html,/&lt;script&gt;/);
});
test('overview previews omit unnecessary exact counts',async()=>{
 const calls=[];const q=new Proxy({}, {get:(_,k)=>k==='then'?resolve=>Promise.resolve({data:[],error:null}).then(resolve):(...args)=>{calls.push([k,...args]);return q;}});
 await createApi({from:()=>q}).preview('enquiries',{size:5});
 assert.equal(calls.find(c=>c[0]==='select').length,2);assert.deepEqual(calls.find(c=>c[0]==='limit'),['limit',5]);
});
