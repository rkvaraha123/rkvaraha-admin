import test from 'node:test';
import assert from 'node:assert/strict';
import {parseHTML} from 'linkedom';
import {build} from 'esbuild';
test('authenticated app navigation, forms, status filtering, and read failures work together',async()=>{
 const {window,document}=parseHTML('<html><body><div id="app"></div><dialog id="dialog"></dialog><div id="toast"></div></body></html>');
 const owner={user_id:'owner-id',full_name:'Rahul Karri',role:'owner',active:true};
 const fixture={id:'contact-id',full_name:'Example Contact',email:'qa@example.invalid',phone:'9000000000',status:'new',created_at:'2026-09-18T00:00:00Z',updated_at:'2026-09-18T00:00:00Z'};
 let offline=false, delayedTable=null, releaseDelayed=null;const calls=[];const audit={id:765,actor_name:'System / integration',action:'insert',entity:'enquiries',record_id:'enquiry-id',changes:{status:{from:null,to:'new'},priority:{from:null,to:'normal'}},created_at:'2026-09-18T00:00:00Z'};
 const fakeQuery=table=>{let single=false;const q=new Proxy({}, {get:(_,key)=>key==='then'?resolve=>{const result=offline?{error:Error('Test connection failed')}:{data:single?owner:table==='contacts'?[fixture]:table==='audit_events'?[audit]:table==='dashboard_users'?[owner]:[],count:['contacts','audit_events'].includes(table)?1:0,error:null};if(table===delayedTable){delayedTable=null;return new Promise(release=>{releaseDelayed=()=>release(result);}).then(resolve);}return Promise.resolve(result).then(resolve);}:(...args)=>{calls.push([table,key,...args]);if(key==='single'||key==='maybeSingle')single=true;return q;}});return q;};
 globalThis.__testDb={from:fakeQuery,rpc:()=>({abortSignal(){return this;},then(resolve){return Promise.resolve({data:{contacts:1,trend:[],pipeline:{new:1},sources:[]},error:null}).then(resolve);}}),auth:{getSession:async()=>({data:{session:{user:{id:'owner-id',email:'owner@example.invalid'}}},error:null}),onAuthStateChange:()=>({}),signOut:async()=>({error:null})}};
 const originals={document:globalThis.document,window:globalThis.window,location:globalThis.location,history:globalThis.history,FormData:globalThis.FormData,setTimeout:globalThis.setTimeout};
 Object.assign(globalThis,{document,window,location:{hash:'',origin:'https://test.invalid'},history:{replaceState(){}},FormData:class{constructor(form){this.values=[...form.querySelectorAll('input,select,textarea')].filter(n=>n.name).map(n=>[n.name,n.value]);}*[Symbol.iterator](){yield* this.values;}}});
 Object.defineProperty(globalThis,'navigator',{value:{onLine:true},configurable:true});
 globalThis.setTimeout=(fn,ms)=>{const timer=originals.setTimeout(fn,ms);timer.unref?.();return timer;};
 const modal=document.querySelector('dialog');modal.showModal=()=>{modal.open=true;};modal.close=()=>{modal.open=false;};
 const bundled=await build({entryPoints:['public/app.js'],bundle:true,write:false,format:'esm',platform:'browser',plugins:[{name:'mock-auth',setup(b){b.onResolve({filter:/^@supabase\/supabase-js$/},()=>({path:'mock',namespace:'test'}));b.onLoad({filter:/.*/,namespace:'test'},()=>({contents:'export const createClient=()=>globalThis.__testDb;',loader:'js'}));}}]});
 const tick=async()=>{for(let i=0;i<12;i++)await new Promise(resolve=>setImmediate(resolve));};
 try{
 await import('data:text/javascript;base64,'+Buffer.from(bundled.outputFiles[0].text).toString('base64'));await tick();
 assert.match(document.querySelector('#page-content').textContent,/Good /);
 for(const page of ['contacts','enquiries','pipeline','tasks','projects','appointments','automations','team','audit','settings']){document.querySelector(`[data-page="${page}"]`).click();await tick();assert.ok(document.querySelector('#page-content h1'),page);assert.doesNotMatch(document.querySelector('#page-content').textContent,/couldn’t load/);}
 document.querySelector('[data-page="audit"]').click();await tick();document.querySelector('[data-action="detail"]').click();await tick();assert.ok(modal.open);assert.match(modal.textContent,/System \/ integration/);assert.match(modal.textContent,/Enquiries/);assert.match(modal.textContent,/Before/);assert.match(modal.textContent,/Normal/);modal.querySelector('[data-action="close"]').click();
 document.querySelector('[data-page="contacts"]').click();await tick();document.querySelector('[data-action="new"]').click();await tick();assert.ok(modal.open);assert.ok(modal.querySelector('[name="full_name"]'));modal.querySelector('[data-action="close"]').click();await tick();assert.equal(modal.open,false);
 document.querySelector('[data-action="contact"]').click();await tick();assert.equal(modal.querySelector('[name="full_name"]').value,'Example Contact');assert.ok(modal.querySelector('#contact-notes'));modal.querySelector('[data-action="close"]').click();
 document.querySelector('[data-page="pipeline"]').click();await tick();document.querySelector('[data-stage="lost"]').click();await tick();assert.ok(calls.some(c=>c[1]==='eq'&&c[2]==='status'&&c[3]==='lost'));
 assert.equal(calls.filter(c=>c[0]==='dashboard_users'&&c[1]==='maybeSingle').length,1,'membership is not requested on every navigation');
 delayedTable='tasks';document.querySelector('[data-page="tasks"]').click();await tick();
 document.querySelector('[data-page="settings"]').click();await tick();releaseDelayed();await tick();
 assert.match(document.querySelector('#page-content h1').textContent,/My account/,'slow prior response cannot replace the current page');
 document.querySelector('[data-page="contacts"]').click();await tick();
 offline=true;window.dispatchEvent(new window.Event('online'));await tick();
 assert.match(document.querySelector('#page-content').textContent,/Example Contact/,'background errors preserve the last successful view');
 assert.match(document.querySelector('#connection').textContent,/last loaded data/);
 document.querySelector('[data-action="refresh"]').click();await tick();assert.match(document.querySelector('#page-content').textContent,/Test connection failed/);
 }finally{Object.assign(globalThis,originals);delete globalThis.__testDb;}
});
