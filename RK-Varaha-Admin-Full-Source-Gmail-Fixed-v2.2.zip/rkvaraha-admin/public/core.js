export const STAGES=['new','contacted','qualified','meeting','won','lost'];
export const PAGE_SIZE=25;
export const labels={overview:'Overview',contacts:'Contacts',enquiries:'Enquiries',pipeline:'Lead pipeline',tasks:'Tasks',projects:'Projects',appointments:'Appointments',automations:'Automations',team:'Team & access',audit:'Audit history',gmail:'Gmail',settings:'My account'};
export function esc(v=''){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
export function human(v){return String(v??'—').replaceAll('_',' ').replace(/^./,x=>x.toUpperCase());}
export function fmt(v,dateOnly=false){if(!v)return '—';const d=new Date(v);if(!Number.isFinite(d.getTime()))return '—';return new Intl.DateTimeFormat('en-IN',{timeZone:'Asia/Kolkata',day:'numeric',month:'short',year:dateOnly?'numeric':undefined,...(dateOnly?{}:{hour:'2-digit',minute:'2-digit'})}).format(d);}
export function safeUrl(v){try{const u=new URL(v);return ['https:','http:'].includes(u.protocol)?u.href:null;}catch{return null;}}
export function csvCell(v){let s=String(v??'');if(/^[\s]*[=+\-@\t\r]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';}
export function csv(rows,columns){return '\uFEFF'+[columns.map(c=>csvCell(c.label)).join(','),...rows.map(r=>columns.map(c=>csvCell(c.value(r))).join(','))].join('\r\n');}
export function searchTerm(v){return String(v).replace(/[^\p{L}\p{N}\s@.+\-]/gu,' ').trim().slice(0,120);}
export function canWrite(role){return ['owner','admin','manager','employee'].includes(role);}
export function canManage(role){return ['owner','admin','manager'].includes(role);}
export function canAdmin(role){return ['owner','admin'].includes(role);}
export function accessiblePages(role){return Object.keys(labels).filter(p=>!(p==='team'&&!canManage(role))&&!(p==='audit'&&!canAdmin(role))&&!(p==='gmail'&&!canAdmin(role))&&!(p==='automations'&&role==='employee'));}
export function toIso(local){if(!local)return null;const d=new Date(local);if(!Number.isFinite(d.getTime()))throw Error('Enter a valid date and time.');return d.toISOString();}
export function localDate(v){if(!v)return '';const d=new Date(v);return new Date(d-d.getTimezoneOffset()*60000).toISOString().slice(0,16);}
export function pageBounds(page,total){const pages=Math.max(1,Math.ceil(total/PAGE_SIZE));const p=Math.min(Math.max(0,page),pages-1);return {page:p,pages,from:total?p*PAGE_SIZE+1:0,to:Math.min((p+1)*PAGE_SIZE,total)};}
