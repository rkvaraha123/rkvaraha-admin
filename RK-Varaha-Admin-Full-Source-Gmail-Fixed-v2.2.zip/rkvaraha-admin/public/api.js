import {PAGE_SIZE,searchTerm} from './core.js';
export const CONFIG={url:'https://puishgbbxlxatkjejfke.supabase.co',key:'sb_publishable_VTCfIIf7wGgEBafBWiyFtQ_e_xOdcoa'};
export const tables={contacts:'contacts',pipeline:'contacts',enquiries:'enquiries',appointments:'appointments',tasks:'tasks',projects:'projects',automations:'automation_logs',team:'dashboard_users',audit:'audit_events'};
const columns={contacts:'id,full_name,email,phone,company,source,status,owner_user_id,created_at,updated_at',pipeline:'id,full_name,email,phone,company,source,status,owner_user_id,created_at,updated_at',enquiries:'id,service,message,page_url,status,priority,utm_source,utm_medium,utm_campaign,created_at,updated_at,contact_id,contacts(full_name,email,phone,company)',appointments:'id,title,start_at,end_at,status,meeting_url,notes,contact_id,updated_at,created_at,contacts(full_name,company)',tasks:'id,title,description,status,priority,due_at,assigned_to,project_id,contact_id,created_by,created_at,updated_at,projects(name)',projects:'id,name,description,status,owner_user_id,due_date,created_at,updated_at',automations:'id,workflow_name,status,message,duration_ms,execution_external_id,workflow_external_id,created_at',team:'user_id,full_name,role,department,active,created_at,updated_at',audit:'id,actor_name,action,entity,record_id,changes,created_at'};
const searchable={contacts:['full_name','email','phone','company'],pipeline:['full_name','email','company'],enquiries:['service','message'],appointments:['title'],tasks:['title','description'],projects:['name','description'],automations:['workflow_name','message'],team:['full_name','department'],audit:['actor_name','entity','action']};
export function unwrap(r){if(r.error)throw r.error;return r.data;}
async function gmailRequest(db,path,{method='GET',body,signal}={}){
 const session=unwrap(await db.auth.getSession())?.session;if(!session?.access_token)throw Error('Your session expired. Sign in again.');
 const response=await fetch('/api/gmail/'+path,{method,signal,headers:{Authorization:`Bearer ${session.access_token}`,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});
 const type=response.headers.get('content-type')||'',text=await response.text();let payload;
 if(type.includes('application/json')){try{payload=JSON.parse(text);}catch{throw Error('The Gmail service returned damaged JSON. Deploy the full source project again.');}}
 else throw Error(response.status===404||/^\s*</.test(text)?'The Gmail server routes are missing. Deploy the full source project, not the static dist ZIP.':'The Gmail service returned an unexpected response.');
 if(!response.ok)throw Error(payload?.error||`Gmail request failed (${response.status}).`);return payload;
}
export function createApi(db){return {
 async membership(uid,signal){let q=db.from('dashboard_users').select('user_id,full_name,role,department,active,updated_at').eq('user_id',uid).maybeSingle();if(signal)q=q.abortSignal(signal);return unwrap(await q);},
 async summary(signal){let q=db.rpc('dashboard_summary');if(signal)q=q.abortSignal(signal);return unwrap(await q);},
 async preview(page,{size=5,status='',period='upcoming',signal}={}){
  let q=db.from(tables[page]).select(columns[page]);
  if(status)q=q.eq('status',status);
  if(page==='appointments'&&period==='upcoming')q=q.gte('start_at',new Date().toISOString());
  q=q.order(page==='appointments'?'start_at':'created_at',{ascending:page==='appointments'}).limit(size);
  if(signal)q=q.abortSignal(signal);const result=await q;unwrap(result);return {rows:result.data||[],total:result.data?.length||0};
 },
 async list(page,{index=0,search='',status='',period='upcoming',size=PAGE_SIZE,signal}={}){
  let q=db.from(tables[page]).select(columns[page],{count:'exact'});
  const term=searchTerm(search);if(term)q=q.or(searchable[page].map(k=>`${k}.ilike.%${term}%`).join(','));
  if(status)q=page==='team'?q.eq('active',status==='active'):q.eq('status',status);
  if(page==='appointments'&&period==='upcoming')q=q.gte('start_at',new Date().toISOString());
  if(page==='appointments'&&period==='past')q=q.lt('start_at',new Date().toISOString());
  q=q.order(page==='appointments'?'start_at':'created_at',{ascending:page==='appointments'&&period!=='past'}).order(page==='team'?'user_id':'id',{ascending:true}).range(index*size,index*size+size-1);
  if(signal)q=q.abortSignal(signal);const result=await q;unwrap(result);return {rows:result.data||[],total:result.count||0};
 },
 async save(page,payload,old){let q=db.from(tables[page]);if(old)q=q.update(payload).eq('id',old.id).eq('updated_at',old.updated_at);else q=q.insert(payload);const r=await q.select('id,updated_at');unwrap(r);if(r.data?.length!==1)throw Error('This record changed or your access changed. Close this form, refresh, and try again.');return r.data[0];},
 async options(table,query=''){let q=db.from(table).select(table==='contacts'?'id,full_name':table==='projects'?'id,name':'user_id,full_name,role').order(table==='contacts'?'full_name':table==='projects'?'name':'full_name').limit(50);if(table==='dashboard_users')q=q.eq('active',true);if(query)q=q.ilike(table==='contacts'?'full_name':table==='projects'?'name':'full_name','%'+searchTerm(query)+'%');return unwrap(await q)||[];},
 async activities(id){return unwrap(await db.from('lead_activities').select('id,title,details,activity_type,created_at').eq('contact_id',id).order('created_at',{ascending:false}).limit(50))||[];},
 async note(id,details,uid){return unwrap(await db.from('lead_activities').insert({contact_id:id,title:'Team note',details,activity_type:'note',performed_by:uid}));},
 async approvals(){return unwrap(await db.from('dashboard_invites').select('email,full_name,role,department,expires_at,accepted_at,revoked,invitation_status,invitation_sent_at,last_error').order('created_at',{ascending:false}).limit(100))||[];},
 async approve(p){return unwrap(await db.functions.invoke('team-invite',{body:{full_name:p.full_name?.trim(),email:p.email?.toLowerCase().trim(),role:p.role,department:p.department?.trim()||null}}));},
 async revoke(email){return unwrap(await db.from('dashboard_invites').update({revoked:true}).eq('email',email).select('email').single());},
 async member(p){return unwrap(await db.rpc('set_team_member',p));},
 async completeOnboarding(){return unwrap(await db.rpc('complete_dashboard_onboarding'));},
 async gmailStatus(signal){return gmailRequest(db,'status',{signal});},
 async gmailConnect(){return gmailRequest(db,'connect',{method:'POST'});},
 async gmailMessages({search='',pageToken='',signal}={}){const q=new URLSearchParams();if(search)q.set('q',search.slice(0,300));if(pageToken)q.set('pageToken',pageToken);return gmailRequest(db,'messages'+(q.size?'?'+q:''),{signal});},
 async gmailMessage(id){return gmailRequest(db,'message/'+encodeURIComponent(id));},
 async gmailSend(payload){return gmailRequest(db,'send',{method:'POST',body:payload});},
 async gmailDisconnect(){return gmailRequest(db,'disconnect',{method:'POST'});}
 };}
