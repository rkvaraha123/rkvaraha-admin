# Google authentication setup

The dashboard code supports Google sign-in through Supabase Auth. Do not put the Google client secret in Netlify, browser JavaScript, GitHub, or this ZIP.

## Required configuration

1. Rotate the Google OAuth client secret that was exposed in the screenshot.
2. In Google Cloud Console, open the Web OAuth client and add this exact Authorized redirect URI:

   `https://puishgbbxlxatkjejfke.supabase.co/auth/v1/callback`

3. In Supabase Dashboard → Authentication → Sign In / Providers → Google:
   - Enable Google.
   - Paste the Google client ID.
   - Paste the newly rotated client secret value.
4. In Supabase Dashboard → Authentication → URL Configuration:
   - Site URL: `https://admin.rkvaraha.com`
   - Additional redirect URL: `https://rkvaraha-admin.netlify.app/**`
5. In Supabase Dashboard → Authentication → Email Templates, brand and test the Invite user, Confirm signup, Reset password, Change email, and Magic link templates.
6. Configure custom SMTP before inviting real employees. The default Supabase mail service is not an enterprise delivery service and is rate limited.

Google authentication and Gmail mailbox access are separate. This sign-in requests identity only; it does not read or send a user's Gmail.
