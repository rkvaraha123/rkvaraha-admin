# Current repair verification

23 tests pass in this release. They cover the earlier dashboard regressions plus Gmail role restrictions, HTML escaping, missing-route detection, and the server JSON setup contract. See FIX-REPORT.md for the audit regression, navigation races, background-read errors, caching checks, and live signed-in results. The following sections record the original baseline validation; capacity limitations still apply.

# Verification report

Release: RK Varaha Workspace v2, 18 September 2026.

## Passed

- 17 automated Node tests: HTML escaping, dangerous URL rejection, CSV formula protection, Lost stage visibility, role-based navigation, viewer restrictions, button behavior, paging, search sanitization, future-meeting filtering, optimistic conflict detection, error propagation, whole-dataset summary access, all module empty states, 200 concurrent simulated query clients, and authenticated UI navigation/modal flows using a mocked Supabase client.
- `npm run build` succeeded; SDK bundled in an approximately 260 KB uncompressed JavaScript asset.
- `npm audit --omit=dev --audit-level=high`: zero reported production dependency vulnerabilities.
- Live Supabase transactional tests: email preapproval and unapproved signup rejection; assigned employee data isolation; viewer read-only behavior; manager cannot approve employees; nonmember denial; blocked self-elevation; audit-write rejection; immediate suspension enforcement; anonymous denial; summary counts above 500 contacts; future meetings after 220 older records.
- Database test fixtures rolled back. Post-test inspection found one original contact, one original enquiry, one original member, and zero QA auth users or QA enquiries.
- Ingestion retry test: repeating one external submission ID created one enquiry. Test rolled back.
- Existing n8n Website Contact Enquiries workflow passed an isolated pinned-output test, execution `17920`. Email, HubSpot, database/data-table and response nodes were simulated to prevent customer messages and production writes. Logic nodes executed. This is not an end-to-end external-service test.
- Supabase security advisor found no database-policy warnings after the changes. One existing Auth warning remains, described below.
- Netlify deployment reported ready; the public sign-in screen was inspected in the browser. No application errors were observed in that inspection. Browser-extension log errors are unrelated to application code.

## Limits of this verification

- The 200-client test uses simulated database responses. It verifies query isolation; it is not a benchmark of 200 real employees.
- One production-data aggregate query completed in approximately 32 ms inside PostgreSQL on the current tiny dataset. This excludes network latency and provides no large-dataset/concurrency guarantee.
- A real owner signed in through the secure browser credential handoff. All 11 sections loaded. Contact details and enquiry messages opened correctly. A temporary task was created in the browser, updated to Done, and independently verified in the live database. The exact temporary task and its test audit events were then removed; no business records were changed.
- Password-reset delivery, employee confirmation emails, actual mobile devices, and a full live enquiry → PostgreSQL → Supabase → HubSpot → SMTP chain were not verified in this release.
- The full set of possible errors cannot be proven absent. The tests target the identified failure modes and security boundaries.

## Remaining rollout gates

1. Complete a new-employee browser walkthrough, including email verification and password recovery. The existing owner browser walkthrough has passed.
2. Enable and validate the available account protections appropriate to the company. Supabase reports **Leaked Password Protection Disabled**. See [Supabase password protection guidance](https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection). No paid plan or authentication setting was changed automatically.
3. Use staging to run a real authenticated load test with the expected number of employees, data volume and read/write mix. Set a latency/error budget, review connection/compute quotas and measure before inviting hundreds of users.
4. Verify backups by restoring into a separate environment; define recovery time and acceptable data loss.
5. Restore GitHub write access and connect the updated repository to Netlify automatic deployment. Until then, the delivered source ZIP is the release handoff.
