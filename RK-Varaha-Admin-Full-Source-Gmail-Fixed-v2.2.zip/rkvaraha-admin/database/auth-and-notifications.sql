begin;

alter table public.dashboard_invites
  add column if not exists invitation_status text not null default 'pending',
  add column if not exists invitation_sent_at timestamptz,
  add column if not exists auth_user_id uuid references auth.users(id) on delete set null,
  add column if not exists last_error text,
  add column if not exists updated_at timestamptz not null default now();

alter table public.dashboard_invites drop constraint if exists dashboard_invites_invitation_status_check;
alter table public.dashboard_invites add constraint dashboard_invites_invitation_status_check
  check (invitation_status in ('pending','sent','accepted','revoked','expired','failed'));

update public.dashboard_invites
set invitation_status = case
  when revoked then 'revoked'
  when accepted_at is not null then 'accepted'
  when expires_at <= now() then 'expired'
  when invitation_sent_at is not null then 'sent'
  else 'pending'
end;

create table if not exists public.notification_outbox (
  id bigint generated always as identity primary key,
  event_type text not null check (event_type in ('employee_invited','employee_registered','employee_access_updated','employee_suspended','employee_reactivated')),
  recipient_email text not null check (position('@' in recipient_email) > 1),
  recipient_name text,
  subject text not null,
  text_body text not null,
  status text not null default 'pending' check (status in ('pending','sent','failed')),
  attempts integer not null default 0 check (attempts between 0 and 20),
  available_at timestamptz not null default now(),
  sent_at timestamptz,
  last_error text,
  dedupe_key text not null unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists notification_outbox_pending_idx
  on public.notification_outbox (available_at, id) where status = 'pending';
create index if not exists dashboard_invites_auth_user_idx
  on public.dashboard_invites (auth_user_id) where auth_user_id is not null;
alter table public.notification_outbox enable row level security;
revoke all on public.notification_outbox from public, anon, authenticated;
grant all on public.notification_outbox to service_role;
grant usage, select on sequence public.notification_outbox_id_seq to service_role;
drop policy if exists notification_outbox_deny_client_access on public.notification_outbox;
create policy notification_outbox_deny_client_access on public.notification_outbox
  for all to anon,authenticated using (false) with check (false);

create or replace function private.queue_dashboard_notification(
  p_event_type text,
  p_recipient_email text,
  p_recipient_name text,
  p_subject text,
  p_text_body text,
  p_dedupe_key text
) returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if p_recipient_email is null or position('@' in p_recipient_email) <= 1 then return; end if;
  insert into public.notification_outbox(event_type,recipient_email,recipient_name,subject,text_body,dedupe_key)
  values(p_event_type,lower(btrim(p_recipient_email)),nullif(btrim(p_recipient_name),''),p_subject,p_text_body,p_dedupe_key)
  on conflict (dedupe_key) do nothing;
end $$;
revoke all on function private.queue_dashboard_notification(text,text,text,text,text,text) from public,anon,authenticated;

create or replace function private.restrict_dashboard_auth_signup() returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.email is null or not exists(
    select 1 from public.dashboard_invites
    where email=lower(btrim(new.email)) and not revoked and accepted_at is null and expires_at>now()
  ) then
    raise insufficient_privilege using message='Ask your administrator to invite your work email before signing in.';
  end if;
  return new;
end $$;
revoke all on function private.restrict_dashboard_auth_signup() from public,anon,authenticated;

create or replace function private.provision_dashboard_user() returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare invitation public.dashboard_invites;
declare owner_email text;
declare owner_name text;
begin
  select * into invitation from public.dashboard_invites
  where email=lower(btrim(new.email)) and not revoked and accepted_at is null and expires_at>now()
  for update;
  if not found then raise insufficient_privilege using message='Employee invitation expired or was revoked.'; end if;

  insert into public.dashboard_users(user_id,full_name,role,department,active)
  values(new.id,invitation.full_name,invitation.role,invitation.department,true)
  on conflict (user_id) do update set
    full_name=excluded.full_name, role=excluded.role, department=excluded.department, active=true;

  update public.dashboard_invites set
    auth_user_id=new.id,
    invitation_status=case when new.invited_at is null then 'accepted' else 'sent' end,
    invitation_sent_at=case when new.invited_at is not null then coalesce(invitation_sent_at,now()) else invitation_sent_at end,
    accepted_at=case when new.invited_at is null then coalesce(accepted_at,now()) else accepted_at end,
    last_error=null,
    updated_at=now()
  where email=invitation.email;

  if new.invited_at is null then
    select u.email,du.full_name into owner_email,owner_name
    from public.dashboard_users du join auth.users u on u.id=du.user_id
    where du.role='owner' and du.active order by du.created_at limit 1;
    perform private.queue_dashboard_notification(
      'employee_registered',owner_email,owner_name,'Employee joined RK Varaha Workspace',
      invitation.full_name||' ('||invitation.email||') completed registration with the '||invitation.role||' role.',
      'employee-registered:'||new.id::text
    );
  end if;
  return new;
end $$;
revoke all on function private.provision_dashboard_user() from public,anon,authenticated;

drop trigger if exists restrict_dashboard_auth_signup_trigger on auth.users;
create trigger restrict_dashboard_auth_signup_trigger before insert on auth.users
for each row execute function private.restrict_dashboard_auth_signup();
drop trigger if exists on_auth_user_created_dashboard_owner on auth.users;
create trigger on_auth_user_created_dashboard_owner after insert on auth.users
for each row execute function private.provision_dashboard_user();

create or replace function private.complete_dashboard_onboarding() returns void
language plpgsql
security definer
set search_path = ''
as $$
declare member_email text;
declare member_name text;
declare owner_email text;
declare owner_name text;
declare changed integer;
begin
  if auth.uid() is null then raise insufficient_privilege; end if;
  select u.email,du.full_name into member_email,member_name
  from auth.users u join public.dashboard_users du on du.user_id=u.id
  where u.id=auth.uid() and du.active;
  if member_email is null then raise insufficient_privilege; end if;

  update public.dashboard_invites set accepted_at=coalesce(accepted_at,now()),invitation_status='accepted',last_error=null,updated_at=now()
  where email=lower(btrim(member_email)) and auth_user_id=auth.uid() and not revoked and accepted_at is null;
  get diagnostics changed = row_count;
  if changed > 0 then
    select u.email,du.full_name into owner_email,owner_name
    from public.dashboard_users du join auth.users u on u.id=du.user_id
    where du.role='owner' and du.active order by du.created_at limit 1;
    perform private.queue_dashboard_notification(
      'employee_registered',owner_email,owner_name,'Employee accepted an RK Varaha invitation',
      member_name||' ('||member_email||') accepted the workspace invitation.',
      'employee-accepted:'||auth.uid()::text
    );
  end if;
end $$;
revoke all on function private.complete_dashboard_onboarding() from public,anon,authenticated;

create or replace function public.complete_dashboard_onboarding() returns void
language sql
security invoker
set search_path = ''
as $$ select private.complete_dashboard_onboarding() $$;
revoke all on function public.complete_dashboard_onboarding() from public,anon;
grant execute on function public.complete_dashboard_onboarding() to authenticated;

create or replace function private.queue_member_access_notification() returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare member_email text;
declare event_name text;
declare mail_subject text;
begin
  if tg_op <> 'UPDATE' or new.role='owner' then return new; end if;
  if (old.role,old.active,old.full_name,old.department) is not distinct from (new.role,new.active,new.full_name,new.department) then return new; end if;
  select email into member_email from auth.users where id=new.user_id;
  event_name:=case when old.active and not new.active then 'employee_suspended' when not old.active and new.active then 'employee_reactivated' else 'employee_access_updated' end;
  mail_subject:=case when event_name='employee_suspended' then 'Your RK Varaha Workspace access was suspended' when event_name='employee_reactivated' then 'Your RK Varaha Workspace access was restored' else 'Your RK Varaha Workspace access was updated' end;
  perform private.queue_dashboard_notification(
    event_name,member_email,new.full_name,mail_subject,
    'Hello '||coalesce(new.full_name,'team member')||E',\n\nYour RK Varaha Workspace access was updated.\nRole: '||new.role||E'\nDepartment: '||coalesce(new.department,'Not assigned')||E'\nAccess: '||case when new.active then 'Active' else 'Suspended' end||E'\n\nIf you did not expect this change, contact your RK Varaha administrator.',
    'employee-access:'||new.user_id::text||':'||extract(epoch from new.updated_at)::text
  );
  return new;
end $$;
revoke all on function private.queue_member_access_notification() from public,anon,authenticated;

drop trigger if exists dashboard_member_email on public.dashboard_users;
create trigger dashboard_member_email after update on public.dashboard_users
for each row execute function private.queue_member_access_notification();

create or replace function private.set_invite_status() returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  new.updated_at:=now();
  if new.revoked then new.invitation_status:='revoked';
  elsif new.accepted_at is not null then new.invitation_status:='accepted';
  elsif new.expires_at<=now() then new.invitation_status:='expired';
  end if;
  return new;
end $$;
revoke all on function private.set_invite_status() from public,anon,authenticated;
drop trigger if exists dashboard_invite_status on public.dashboard_invites;
create trigger dashboard_invite_status before update on public.dashboard_invites
for each row execute function private.set_invite_status();

notify pgrst,'reload schema';
commit;
