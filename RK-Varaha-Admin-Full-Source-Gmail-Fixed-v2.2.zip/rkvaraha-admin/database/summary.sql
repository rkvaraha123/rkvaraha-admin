create or replace function public.dashboard_summary() returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object(
 'contacts',(select count(*) from public.contacts),
 'qualified',(select count(*) from public.contacts where status='qualified'),
 'won',(select count(*) from public.contacts where status='won'),
 'open_enquiries',(select count(*) from public.enquiries where status in ('new','in_progress')),
 'upcoming',(select count(*) from public.appointments where status='scheduled' and start_at>=now()),
 'overdue_tasks',(select count(*) from public.tasks where status<>'done' and due_at<now()),
 'open_tasks',(select count(*) from public.tasks where status<>'done'),
 'failed_24h',(select count(*) from public.automation_logs where status='failed' and created_at>=now()-interval '24 hours'),
 'pipeline',(select coalesce(jsonb_object_agg(status,n),'{}'::jsonb) from (select status,count(*) n from public.contacts group by status) s),
 'sources',(select coalesce(jsonb_agg(s),'[]'::jsonb) from (select coalesce(nullif(utm_source,''),'Direct') source,count(*) total from public.enquiries group by 1 order by 2 desc limit 8) s),
 'trend',(select jsonb_agg(t order by t.day) from (select d::date as "day",count(e.id) total from generate_series(((now() at time zone 'Asia/Kolkata')::date-13)::timestamp,((now() at time zone 'Asia/Kolkata')::date)::timestamp,interval '1 day') d left join public.enquiries e on e.created_at >= (d at time zone 'Asia/Kolkata') and e.created_at < ((d+interval '1 day') at time zone 'Asia/Kolkata') group by 1) t)
 )
$$;
