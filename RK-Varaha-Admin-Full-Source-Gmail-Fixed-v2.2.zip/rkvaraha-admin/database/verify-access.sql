-- Transactional verification: all fixture users, records, and audit entries roll back.
begin;
insert into public.dashboard_invites(email,full_name,role) values
 ('rkv-qa-employee@example.invalid','QA Employee','employee'),
 ('rkv-qa-viewer@example.invalid','QA Viewer','viewer'),
 ('rkv-qa-manager@example.invalid','QA Manager','manager');
insert into auth.users(id,email,email_confirmed_at) values
 ('00000000-0000-4000-a000-000000000101','rkv-qa-employee@example.invalid',now()),
 ('00000000-0000-4000-a000-000000000102','rkv-qa-viewer@example.invalid',now()),
 ('00000000-0000-4000-a000-000000000103','rkv-qa-manager@example.invalid',now());
do $$ begin
 begin insert into auth.users(id,email) values('00000000-0000-4000-a000-000000000199','rkv-qa-unapproved@example.invalid');raise exception 'FAIL: unapproved signup allowed';exception when insufficient_privilege then null;end;
 if (select role from public.dashboard_users where user_id='00000000-0000-4000-a000-000000000101')<>'employee' then raise exception 'FAIL: approval role not applied'; end if;
end $$;
insert into public.contacts(id,full_name,email,owner_user_id) values
 ('00000000-0000-4000-a000-000000000201','QA Assigned','assigned@example.invalid','00000000-0000-4000-a000-000000000101');
insert into public.contacts(full_name,email) select 'QA Scale '||n,'rkv-qa-'||n||'@example.invalid' from generate_series(1,520) n;
insert into public.appointments(title,start_at,status) select 'QA Past '||n,now()-interval '1 day'*n,'completed' from generate_series(1,220)n;
insert into public.appointments(title,start_at,status,contact_id) values('QA Future',now()+interval '1 day','scheduled','00000000-0000-4000-a000-000000000201');
insert into public.tasks(title,assigned_to) values('QA Task','00000000-0000-4000-a000-000000000101');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"00000000-0000-4000-a000-000000000101","role":"authenticated"}',true);
do $$ declare n integer; begin
 if (select count(*) from public.contacts)<>1 then raise exception 'FAIL: employee reads other contacts'; end if;
 if (select count(*) from public.tasks)<>1 then raise exception 'FAIL: assigned task missing'; end if;
 if (select count(*) from public.appointments)<>1 then raise exception 'FAIL: appointment isolation'; end if;
 update public.contacts set status='won' where id='00000000-0000-4000-a000-000000000201';get diagnostics n=row_count;
 if n<>1 then raise exception 'FAIL: assigned update denied';end if;
 begin insert into public.contacts(full_name)values('Forbidden');raise exception 'FAIL: employee can create unassigned contact';exception when insufficient_privilege then null;end;
 begin update public.dashboard_users set role='owner' where user_id=auth.uid();raise exception 'FAIL: self elevation allowed';exception when insufficient_privilege then null;end;
 begin perform public.set_team_member(auth.uid(),'admin',true,'QA','QA');raise exception 'FAIL: employee can manage membership';exception when insufficient_privilege then null;end;
 begin insert into public.audit_events(action,entity)values('forged','contacts');raise exception 'FAIL: audit forgery allowed';exception when insufficient_privilege then null;end;
end $$;
select set_config('request.jwt.claims','{"sub":"00000000-0000-4000-a000-000000000102","role":"authenticated"}',true);
do $$ declare n integer;s jsonb;begin
 s:=public.dashboard_summary();if (s->>'contacts')::int<521 then raise exception 'FAIL: metrics truncated at 500';end if;
 if (s->>'upcoming')::int<1 then raise exception 'FAIL: upcoming meeting hidden behind old records';end if;
 update public.contacts set status='lost' where id='00000000-0000-4000-a000-000000000201';get diagnostics n=row_count;if n<>0 then raise exception 'FAIL: viewer can write';end if;
 begin insert into public.tasks(title)values('Forbidden');raise exception 'FAIL: viewer can create task';exception when insufficient_privilege then null;end;
end $$;
select set_config('request.jwt.claims','{"sub":"00000000-0000-4000-a000-000000000103","role":"authenticated"}',true);
do $$ begin
 if (select count(*) from public.contacts)<521 then raise exception 'FAIL: manager scope';end if;
 begin insert into public.dashboard_invites(email,full_name)values('forbidden@example.invalid','Forbidden');raise exception 'FAIL: manager can approve access';exception when insufficient_privilege then null;end;
end $$;
select set_config('request.jwt.claims','{"sub":"00000000-0000-4000-a000-000000000999","role":"authenticated"}',true);
do $$ begin
 if (select count(*) from public.contacts)<>0 then raise exception 'FAIL: nonmember reads contacts';end if;
 if (select count(*) from public.tasks)<>0 then raise exception 'FAIL: nonmember reads tasks';end if;
 begin perform public.set_team_member('00000000-0000-4000-a000-000000000101','admin',true,'QA','QA');raise exception 'FAIL: nonmember manages team';exception when insufficient_privilege then null;end;
end $$;
reset role;
update public.dashboard_users set active=false where user_id='00000000-0000-4000-a000-000000000101';
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"00000000-0000-4000-a000-000000000101","role":"authenticated"}',true);
do $$ begin if (select count(*) from public.contacts)<>0 then raise exception 'FAIL: suspended employee retains access';end if;end $$;
reset role;
set local role anon;
do $$ begin
 begin if (select count(*) from public.contacts)>0 then raise exception 'FAIL: anonymous reads contacts';end if;exception when insufficient_privilege then null;end;
 begin perform public.dashboard_summary();raise exception 'FAIL: anonymous can call summary';exception when insufficient_privilege then null;end;
end $$;
reset role;
rollback;
select 'PASS: signup approvals, employee isolation, viewer read-only, manager boundaries, blocked self-elevation, immutable audit, nonmember denial, suspension, anonymous denial, complete counts >500, future meetings after 220 old records. All fixtures rolled back.' as verification;
