CREATE OR REPLACE FUNCTION public.ingest_rkvaraha_enquiry(p_external_submission_id text DEFAULT NULL::text, p_full_name text DEFAULT NULL::text, p_email text DEFAULT NULL::text, p_phone text DEFAULT NULL::text, p_company text DEFAULT NULL::text, p_service text DEFAULT NULL::text, p_message text DEFAULT NULL::text, p_page_url text DEFAULT NULL::text, p_utm_source text DEFAULT NULL::text, p_utm_medium text DEFAULT NULL::text, p_utm_campaign text DEFAULT NULL::text, p_workflow_name text DEFAULT NULL::text, p_workflow_execution_id text DEFAULT NULL::text, p_channel text DEFAULT 'website'::text, p_form_name text DEFAULT NULL::text, p_raw_payload jsonb DEFAULT '{}'::jsonb, p_consent_privacy boolean DEFAULT NULL::boolean, p_consent_marketing boolean DEFAULT NULL::boolean)
 RETURNS TABLE(contact_id uuid, enquiry_id uuid, duplicate boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
declare
  v_contact_id uuid;
  v_enquiry_id uuid;
  v_email text := nullif(lower(btrim(p_email)), '');
  v_phone text := nullif(regexp_replace(coalesce(p_phone,''), '[^0-9]+', '', 'g'), '');
  v_source text := coalesce(nullif(btrim(p_utm_source), ''), 'direct');
begin
  -- Serialize retries and matching identities to prevent concurrent duplicate inserts.
  if nullif(btrim(p_external_submission_id),'') is not null then
    perform pg_advisory_xact_lock(hashtextextended('rkv:submission:'||btrim(p_external_submission_id),0));
  end if;
  if v_email is not null then perform pg_advisory_xact_lock(hashtextextended('rkv:email:'||v_email,0)); end if;
  if v_phone is not null then perform pg_advisory_xact_lock(hashtextextended('rkv:phone:'||v_phone,0)); end if;
  if nullif(btrim(p_external_submission_id), '') is not null then
    select e.contact_id, e.id
      into v_contact_id, v_enquiry_id
    from public.enquiries e
    where e.external_submission_id = btrim(p_external_submission_id)
    limit 1;

    if found then
      return query select v_contact_id, v_enquiry_id, true;
      return;
    end if;
  end if;

  if v_email is not null then
    select c.id into v_contact_id
    from public.contacts c
    where c.normalized_email = v_email
    limit 1;
  end if;

  if v_contact_id is null and v_phone is not null then
    select c.id into v_contact_id
    from public.contacts c
    where c.normalized_phone = v_phone
    order by c.created_at asc
    limit 1;
  end if;

  if v_contact_id is null then
    insert into public.contacts (
      full_name, email, phone, company, source,
      first_touch_source, last_touch_source, status, last_enquiry_at
    )
    values (
      coalesce(nullif(btrim(p_full_name), ''), 'Website Lead'),
      nullif(btrim(p_email), ''),
      nullif(btrim(p_phone), ''),
      nullif(btrim(p_company), ''),
      v_source,
      v_source,
      v_source,
      'new',
      now()
    )
    returning id into v_contact_id;
  else
    update public.contacts
    set
      full_name = coalesce(nullif(btrim(p_full_name), ''), full_name),
      email = coalesce(nullif(btrim(p_email), ''), email),
      phone = coalesce(nullif(btrim(p_phone), ''), phone),
      company = coalesce(nullif(btrim(p_company), ''), company),
      source = coalesce(source, v_source),
      first_touch_source = coalesce(first_touch_source, source, v_source),
      last_touch_source = v_source,
      last_enquiry_at = now(),
      updated_at = now()
    where id = v_contact_id;
  end if;

  insert into public.enquiries (
    contact_id, service, message, page_url,
    utm_source, utm_medium, utm_campaign,
    status, priority,
    external_submission_id, workflow_name, workflow_execution_id,
    channel, form_name, raw_payload,
    consent_privacy, consent_marketing, received_at
  )
  values (
    v_contact_id,
    nullif(btrim(p_service), ''),
    nullif(btrim(p_message), ''),
    nullif(btrim(p_page_url), ''),
    nullif(btrim(p_utm_source), ''),
    nullif(btrim(p_utm_medium), ''),
    nullif(btrim(p_utm_campaign), ''),
    'new',
    'normal',
    nullif(btrim(p_external_submission_id), ''),
    nullif(btrim(p_workflow_name), ''),
    nullif(btrim(p_workflow_execution_id), ''),
    coalesce(nullif(btrim(p_channel), ''), 'website'),
    nullif(btrim(p_form_name), ''),
    coalesce(p_raw_payload, '{}'::jsonb),
    p_consent_privacy,
    p_consent_marketing,
    now()
  )
  returning id into v_enquiry_id;

  insert into public.lead_activities (
    contact_id, activity_type, title, details
  )
  values (
    v_contact_id,
    'enquiry_received',
    'New website enquiry',
    concat_ws(' · ',
      nullif(btrim(p_service), ''),
      nullif(btrim(p_form_name), ''),
      nullif(btrim(p_page_url), '')
    )
  );

  return query select v_contact_id, v_enquiry_id, false;
end;
$function$

