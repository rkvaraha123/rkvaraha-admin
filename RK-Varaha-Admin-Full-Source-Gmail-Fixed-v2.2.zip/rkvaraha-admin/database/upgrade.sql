-- RK Varaha operations upgrade. Additive business schema; preserves existing records.
begin;
create schema if not exists private;
revoke all on schema private from public, anon;
grant usage on schema private to authenticated;
alter table public.dashboard_users drop constraint if exists dashboard_users_role_check;
alter table public.dashboard_users add constraint dashboard_users_role_check check (role in ('owner','admin','manager','employee','viewer'));
alter table public.dashboard_users alter column role set default 'employee';
alter table public.dashboard_users add column if not exists department text;

-- A private helper is necessary to read membership without recursive RLS.
create or replace function private.dashboard_role() returns text language sql stable security definer set search_path='' as $$
 select role from public.dashboard_users where user_id=(select auth.uid()) and active
$$;
revoke all on function private.dashboard_role() from public,anon;
grant execute on function private.dashboard_role() to authenticated;

create table if not exists public.dashboard_invites (
 email text primary key check(email=lower(btrim(email)) and position('@' in email)>1),
 full_name text not null, role text not null default 'employee' check(role in ('admin','manager','employee','viewer')),
 department text, created_by uuid references auth.users(id), created_at timestamptz not null default now(),
 expires_at timestamptz not null default now()+interval '7 days', accepted_at timestamptz,
 revoked boolean not null default false
);
create table if not exists public.projects (
 id uuid primary key default gen_random_uuid(),name text not null check(length(btrim(name))>0),
 description text,status text not null default 'active' check(status in ('planned','active','on_hold','completed','archived')),
 owner_user_id uuid references auth.users(id), due_date date,
 created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create table if not exists public.tasks (
 id uuid primary key default gen_random_uuid(),title text not null check(length(btrim(title))>0),description text,
 project_id uuid references public.projects(id),contact_id uuid references public.contacts(id),
 assigned_to uuid references auth.users(id),created_by uuid references auth.users(id) default auth.uid(),
 status text not null default 'todo' check(status in ('todo','in_progress','blocked','done')),
 priority text not null default 'normal' check(priority in ('low','normal','high','urgent')),due_at timestamptz,
 created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create table if not exists public.audit_events (
 id bigint generated always as identity primary key,actor_id uuid,actor_name text,
 action text not null,entity text not null,record_id text,changes jsonb not null default '{}',
 created_at timestamptz not null default now()
);
create index if not exists projects_owner_idx on public.projects(owner_user_id);
create index if not exists tasks_assigned_status_due_idx on public.tasks(assigned_to,status,due_at);
create index if not exists tasks_project_idx on public.tasks(project_id);
create index if not exists tasks_contact_idx on public.tasks(contact_id);
create index if not exists tasks_creator_idx on public.tasks(created_by);
create index if not exists tasks_created_idx on public.tasks(created_at desc,id);
create index if not exists audit_events_created_idx on public.audit_events(created_at desc,id);
create index if not exists dashboard_invites_creator_idx on public.dashboard_invites(created_by);
create index if not exists contacts_status_created_idx on public.contacts(status,created_at desc,id);
create index if not exists appointments_status_start_idx on public.appointments(status,start_at,id);
create index if not exists enquiries_status_created_idx on public.enquiries(status,created_at desc,id);
create index if not exists automation_logs_status_created_idx on public.automation_logs(status,created_at desc,id);

-- Rebuild the dashboard policies explicitly, with employees limited to assigned work.
do $$ declare r record; begin
 for r in select tablename,policyname from pg_policies where schemaname='public' and tablename in
 ('dashboard_users','contacts','enquiries','lead_activities','appointments','automation_logs','dashboard_invites','projects','tasks','audit_events') loop
 execute format('drop policy %I on public.%I',r.policyname,r.tablename); end loop;
end $$;
alter table public.dashboard_invites enable row level security;
alter table public.projects enable row level security;
alter table public.tasks enable row level security;
alter table public.audit_events enable row level security;
revoke all on public.dashboard_invites,public.projects,public.tasks,public.audit_events from anon,authenticated;
grant select,insert,update on public.dashboard_invites,public.projects,public.tasks to authenticated;
grant select on public.audit_events to authenticated;
revoke insert,update,delete on public.dashboard_users from authenticated,anon;
revoke insert,update,delete on public.automation_logs from authenticated,anon;
grant select on public.dashboard_users,public.automation_logs to authenticated;
grant all on public.dashboard_invites,public.projects,public.tasks,public.audit_events to service_role;

create policy membership_read on public.dashboard_users for select to authenticated using
 (user_id=(select auth.uid()) or (select private.dashboard_role()) in ('owner','admin','manager'));
create policy contacts_read on public.contacts for select to authenticated using
 ((select private.dashboard_role()) in ('owner','admin','manager','viewer') or ((select private.dashboard_role())='employee' and owner_user_id=(select auth.uid())));
create policy contacts_insert on public.contacts for insert to authenticated with check
 ((select private.dashboard_role()) in ('owner','admin','manager') or ((select private.dashboard_role())='employee' and owner_user_id=(select auth.uid())));
create policy contacts_update on public.contacts for update to authenticated using
 ((select private.dashboard_role()) in ('owner','admin','manager') or ((select private.dashboard_role())='employee' and owner_user_id=(select auth.uid()))) with check
 ((select private.dashboard_role()) in ('owner','admin','manager') or ((select private.dashboard_role())='employee' and owner_user_id=(select auth.uid())));
create policy enquiries_read on public.enquiries for select to authenticated using
 ((select private.dashboard_role()) in ('owner','admin','manager','viewer') or ((select private.dashboard_role())='employee' and contact_id in (select id from public.contacts)));
create policy enquiries_update on public.enquiries for update to authenticated using
 ((select private.dashboard_role()) in ('owner','admin','manager') or ((select private.dashboard_role())='employee' and contact_id in (select id from public.contacts))) with check
 ((select private.dashboard_role()) in ('owner','admin','manager') or ((select private.dashboard_role())='employee' and contact_id in (select id from public.contacts)));
create policy activities_read on public.lead_activities for select to authenticated using
 ((select private.dashboard_role()) is not null and contact_id in (select id from public.contacts));
create policy activities_insert on public.lead_activities for insert to authenticated with check
 ((select private.dashboard_role()) in ('owner','admin','manager','employee') and performed_by=(select auth.uid()) and contact_id in (select id from public.contacts));
create policy appointments_read on public.appointments for select to authenticated using
 ((select private.dashboard_role()) in ('owner','admin','manager','viewer') or ((select private.dashboard_role())='employee' and contact_id in (select id from public.contacts)));
create policy appointments_insert on public.appointments for insert to authenticated with check
 ((select private.dashboard_role()) in ('owner','admin','manager') or ((select private.dashboard_role())='employee' and contact_id in (select id from public.contacts)));
create policy appointments_update on public.appointments for update to authenticated using
 ((select private.dashboard_role()) in ('owner','admin','manager') or ((select private.dashboard_role())='employee' and contact_id in (select id from public.contacts))) with check
 ((select private.dashboard_role()) in ('owner','admin','manager') or ((select private.dashboard_role())='employee' and contact_id in (select id from public.contacts)));
create policy automations_read on public.automation_logs for select to authenticated using
 ((select private.dashboard_role()) in ('owner','admin','manager','viewer'));
create policy invites_admin on public.dashboard_invites for all to authenticated using
 ((select private.dashboard_role()) in ('owner','admin')) with check
 ((select private.dashboard_role()) in ('owner','admin') and role<>'owner');
create policy tasks_read on public.tasks for select to authenticated using
 ((select private.dashboard_role()) in ('owner','admin','manager','viewer') or ((select private.dashboard_role())='employee' and assigned_to=(select auth.uid())));
create policy tasks_insert on public.tasks for insert to authenticated with check
 (created_by=(select auth.uid()) and ((select private.dashboard_role()) in ('owner','admin','manager') or ((select private.dashboard_role())='employee' and assigned_to=(select auth.uid()))));
create policy tasks_update on public.tasks for update to authenticated using
 ((select private.dashboard_role()) in ('owner','admin','manager') or ((select private.dashboard_role())='employee' and assigned_to=(select auth.uid()))) with check
 ((select private.dashboard_role()) in ('owner','admin','manager') or ((select private.dashboard_role())='employee' and assigned_to=(select auth.uid())));
create policy projects_read on public.projects for select to authenticated using
 ((select private.dashboard_role()) in ('owner','admin','manager','viewer') or ((select private.dashboard_role())='employee' and (owner_user_id=(select auth.uid()) or id in (select project_id from public.tasks))));
create policy projects_insert on public.projects for insert to authenticated with check ((select private.dashboard_role()) in ('owner','admin','manager'));
create policy projects_update on public.projects for update to authenticated using ((select private.dashboard_role()) in ('owner','admin','manager')) with check ((select private.dashboard_role()) in ('owner','admin','manager'));
create policy audit_read on public.audit_events for select to authenticated using ((select private.dashboard_role()) in ('owner','admin'));

-- Only preapproved, unexpired emails may create an employee account.
create or replace function public.restrict_dashboard_auth_signup() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from public.dashboard_invites where email=lower(btrim(new.email)) and not revoked and accepted_at is null and expires_at>now()) then
  raise insufficient_privilege using message='Ask your administrator to approve your work email before registering.';
 end if;
 return new;
end $$;
create or replace function public.handle_first_dashboard_owner() returns trigger language plpgsql security definer set search_path='' as $$
declare invitation public.dashboard_invites;
begin
 select * into invitation from public.dashboard_invites where email=lower(btrim(new.email)) and not revoked and accepted_at is null and expires_at>now() for update;
 if not found then raise insufficient_privilege using message='Employee approval expired or was revoked.'; end if;
 insert into public.dashboard_users(user_id,full_name,role,department,active) values(new.id,invitation.full_name,invitation.role,invitation.department,true);
 update public.dashboard_invites set accepted_at=now() where email=invitation.email;
 return new;
end $$;
revoke all on function public.restrict_dashboard_auth_signup(),public.handle_first_dashboard_owner() from public,anon,authenticated;

-- Privileged membership management is isolated; public RPC is an invoker wrapper.
create or replace function private.set_team_member(p_user_id uuid,p_role text,p_active boolean,p_name text,p_department text) returns void language plpgsql security definer set search_path='' as $$
declare actor_role text;
begin
 actor_role:=private.dashboard_role();
 if auth.uid() is null or coalesce(actor_role,'') not in ('owner','admin') then raise insufficient_privilege; end if;
 if p_role not in ('admin','manager','employee','viewer') then raise exception 'Invalid role'; end if;
 if p_user_id=auth.uid() then raise exception 'You cannot change your own access.'; end if;
 perform 1 from public.dashboard_users where user_id=p_user_id and role<>'owner' for update;
 if not found then raise exception 'Member not found or protected owner.'; end if;
 update public.dashboard_users set role=p_role,active=p_active,full_name=nullif(btrim(p_name),''),department=nullif(btrim(p_department),'') where user_id=p_user_id;
end $$;
revoke all on function private.set_team_member(uuid,text,boolean,text,text) from public,anon;
grant execute on function private.set_team_member(uuid,text,boolean,text,text) to authenticated;
create or replace function public.set_team_member(p_user_id uuid,p_role text,p_active boolean,p_name text,p_department text) returns void language sql security invoker set search_path='' as $$select private.set_team_member(p_user_id,p_role,p_active,p_name,p_department)$$;
revoke all on function public.set_team_member(uuid,text,boolean,text,text) from public,anon;
grant execute on function public.set_team_member(uuid,text,boolean,text,text) to authenticated;

-- Append-only audit history; no passwords, messages, or complete customer payloads.
create or replace function private.audit_dashboard_change() returns trigger language plpgsql security definer set search_path='' as $$
declare v jsonb; oldv jsonb; delta jsonb; actor text;
begin
 v:=to_jsonb(new); oldv:=case when tg_op='UPDATE' then to_jsonb(old) else '{}'::jsonb end;
 select full_name into actor from public.dashboard_users where user_id=auth.uid();
 select coalesce(jsonb_object_agg(key,jsonb_build_object('from',oldv->key,'to',value)),'{}'::jsonb) into delta
 from jsonb_each(v) where key in ('status','role','active','priority','owner_user_id','assigned_to','revoked') and (oldv->key) is distinct from value;
 insert into public.audit_events(actor_id,actor_name,action,entity,record_id,changes)
 values(auth.uid(),coalesce(actor,'System / integration'),lower(tg_op),tg_table_name,coalesce(v->>'id',v->>'user_id',v->>'email'),delta);
 return new;
end $$;
revoke all on function private.audit_dashboard_change() from public,anon,authenticated;
do $$ declare t text; begin
 foreach t in array array['contacts','enquiries','appointments','projects','tasks','dashboard_users','dashboard_invites'] loop
 execute format('drop trigger if exists dashboard_audit on public.%I',t);
 execute format('create trigger dashboard_audit after insert or update on public.%I for each row execute function private.audit_dashboard_change()',t);
 end loop;
 foreach t in array array['tasks','projects'] loop
 execute format('drop trigger if exists dashboard_updated on public.%I',t);
 execute format('create trigger dashboard_updated before update on public.%I for each row execute function public.set_updated_at()',t);
 end loop;
end $$;

-- Metrics aggregate the entire permitted dataset, never a client-side page.
create or replace function public.dashboard_summary() returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object(
 'contacts',(select count(*) from public.contacts),
 'qualified',(select count(*) from public.contacts where status='qualified'),
 'won',(select count(*) from public.contacts where status='won'),
 'open_enquiries',(select count(*) from public.enquiries where status in ('new','in_progress')),
 'upcoming',(select count(*) from public.appointments where status='scheduled' and start_at>=now()),
 'overdue_tasks',(select count(*) from public.tasks where status<>'done' and due_at<now()),
 'open_tasks',(select count(*) from public.tasks where status<>'done'),
 'failed_24h',(select count(*) from public.automation_logs where status='failed' and created_at>=now()-interval '24 hours'),
 'pipeline',(select coalesce(jsonb_object_agg(status,n),'{}'::jsonb) from (select status,count(*) n from public.contacts group by status) s),
 'sources',(select coalesce(jsonb_agg(s),'[]'::jsonb) from (select coalesce(nullif(utm_source,''),'Direct') source,count(*) total from public.enquiries group by 1 order by 2 desc limit 8) s),
 'trend',(select jsonb_agg(t order by t.day) from (select d::date as "day",count(e.id) total from generate_series(((now() at time zone 'Asia/Kolkata')::date-13)::timestamp,((now() at time zone 'Asia/Kolkata')::date)::timestamp,interval '1 day') d left join public.enquiries e on e.created_at >= (d at time zone 'Asia/Kolkata') and e.created_at < ((d+interval '1 day') at time zone 'Asia/Kolkata') group by 1) t)
 )
$$;
revoke all on function public.dashboard_summary() from public,anon;
grant execute on function public.dashboard_summary() to authenticated;
notify pgrst,'reload schema';
commit;
