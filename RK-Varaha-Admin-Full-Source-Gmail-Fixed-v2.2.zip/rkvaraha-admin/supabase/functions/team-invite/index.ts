import 'jsr:@supabase/functions-js/edge-runtime.d.ts'
import { createClient } from 'npm:@supabase/supabase-js@2.116.0'

const allowedOrigins = new Set([
  'https://admin.rkvaraha.com',
  'https://rkvaraha-admin.netlify.app',
])

const json = (origin: string | null, status: number, body: Record<string, unknown>) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': origin && allowedOrigins.has(origin) ? origin : 'https://admin.rkvaraha.com',
      'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Vary': 'Origin',
    },
  })

Deno.serve(async (req: Request) => {
  const origin = req.headers.get('Origin')
  if (req.method === 'OPTIONS') return json(origin, 200, { ok: true })
  if (req.method !== 'POST') return json(origin, 405, { error: 'Method not allowed.' })
  if (origin && !allowedOrigins.has(origin)) return json(origin, 403, { error: 'Origin not allowed.' })

  const supabaseUrl = Deno.env.get('SUPABASE_URL')
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  const authHeader = req.headers.get('Authorization')
  if (!supabaseUrl || !serviceKey || !authHeader?.startsWith('Bearer ')) {
    return json(origin, 401, { error: 'Authentication required.' })
  }

  const admin = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  })
  const token = authHeader.slice('Bearer '.length)
  const { data: authData, error: authError } = await admin.auth.getUser(token)
  if (authError || !authData.user) return json(origin, 401, { error: 'Your session is no longer valid.' })

  const { data: actor, error: actorError } = await admin
    .from('dashboard_users')
    .select('role,active,full_name')
    .eq('user_id', authData.user.id)
    .maybeSingle()
  if (actorError || !actor?.active || !['owner', 'admin'].includes(actor.role)) {
    return json(origin, 403, { error: 'Owner or administrator access is required.' })
  }

  let payload: Record<string, unknown>
  try { payload = await req.json() } catch { return json(origin, 400, { error: 'Invalid request.' }) }
  const email = String(payload.email ?? '').trim().toLowerCase()
  const fullName = String(payload.full_name ?? '').trim()
  const department = String(payload.department ?? '').trim().slice(0, 120) || null
  const role = String(payload.role ?? 'employee')
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return json(origin, 400, { error: 'Enter a valid work email.' })
  if (!fullName || fullName.length > 180) return json(origin, 400, { error: 'Enter the employee name.' })
  if (!['admin', 'manager', 'employee', 'viewer'].includes(role)) return json(origin, 400, { error: 'Choose a valid access role.' })

  const expiresAt = new Date(Date.now() + 7 * 86_400_000).toISOString()
  const { error: approvalError } = await admin.from('dashboard_invites').upsert({
    email,
    full_name: fullName,
    role,
    department,
    created_by: authData.user.id,
    expires_at: expiresAt,
    accepted_at: null,
    revoked: false,
    invitation_status: 'pending',
    invitation_sent_at: null,
    auth_user_id: null,
    last_error: null,
  }, { onConflict: 'email' })
  if (approvalError) return json(origin, 500, { error: 'The invitation could not be prepared.' })

  const { data: invited, error: inviteError } = await admin.auth.admin.inviteUserByEmail(email, {
    redirectTo: 'https://admin.rkvaraha.com',
    data: { full_name: fullName, department, role },
  })
  if (inviteError || !invited.user) {
    const safeError = inviteError?.message?.slice(0, 300) || 'Invitation provider did not accept the request.'
    await admin.from('dashboard_invites').update({ invitation_status: 'failed', last_error: safeError }).eq('email', email)
    const alreadyExists = /already|registered|exists/i.test(safeError)
    return json(origin, alreadyExists ? 409 : 502, { error: alreadyExists ? 'This email already has an account or invitation. Ask the employee to sign in or reset the password.' : 'The invitation email could not be sent.' })
  }

  await admin.from('dashboard_invites').update({
    auth_user_id: invited.user.id,
    invitation_status: 'sent',
    invitation_sent_at: new Date().toISOString(),
    last_error: null,
  }).eq('email', email)

  const { data: owner } = await admin.from('dashboard_users').select('user_id,full_name').eq('role', 'owner').eq('active', true).limit(1).maybeSingle()
  if (owner?.user_id) {
    const { data: ownerAccount } = await admin.auth.admin.getUserById(owner.user_id)
    const ownerEmail = ownerAccount.user?.email
    if (ownerEmail) await admin.from('notification_outbox').insert({
      event_type: 'employee_invited',
      recipient_email: ownerEmail,
      recipient_name: owner.full_name,
      subject: 'RK Varaha employee invitation sent',
      text_body: `${actor.full_name || 'An administrator'} invited ${fullName} (${email}) with the ${role} role. The invitation expires in 7 days.`,
      dedupe_key: `employee-invited:${invited.user.id}`,
    })
  }

  return json(origin, 200, { success: true, email, expires_at: expiresAt })
})
