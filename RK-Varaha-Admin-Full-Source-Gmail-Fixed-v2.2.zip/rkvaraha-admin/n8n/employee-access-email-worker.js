import { workflow, node, trigger, newCredential, expr } from '@n8n/workflow-sdk';

const everyFiveMinutes = trigger({
  type: 'n8n-nodes-base.scheduleTrigger',
  version: 1.3,
  config: {
    name: 'Every 5 Minutes',
    parameters: {
      rule: { interval: [{ field: 'minutes', minutesInterval: 5 }] }
    }
  },
  output: [{ triggered_at: '2026-09-19T06:00:00.000Z' }]
});

const fetchPending = node({
  type: 'n8n-nodes-base.supabase',
  version: 1,
  config: {
    name: 'Fetch Pending Emails',
    parameters: {
      resource: 'row',
      operation: 'getAll',
      tableId: 'notification_outbox',
      returnAll: false,
      limit: 20,
      orderBy: 'id',
      filterType: 'manual',
      matchType: 'allFilters',
      filters: {
        conditions: [
          { keyName: 'status', condition: 'eq', keyValue: 'pending' },
          { keyName: 'available_at', condition: 'lte', keyValue: expr('{{ $now.toISO() }}') }
        ]
      }
    },
    credentials: { supabaseApi: newCredential('RK Varaha Supabase') }
  },
  output: [{
    id: 1,
    event_type: 'employee_access_updated',
    recipient_email: 'employee@example.com',
    recipient_name: 'Employee',
    subject: 'Your RK Varaha Workspace access was updated',
    text_body: 'Your workspace access was updated.',
    status: 'pending',
    attempts: 0,
    available_at: '2026-09-19T06:00:00.000Z'
  }]
});

const sendEmail = node({
  type: 'n8n-nodes-base.emailSend',
  version: 2.1,
  config: {
    name: 'Send Access Email',
    parameters: {
      resource: 'email',
      operation: 'send',
      fromEmail: 'RK Varaha <rahulkarri@rkvaraha.com>',
      toEmail: expr('{{ $json.recipient_email }}'),
      subject: expr('{{ $json.subject }}'),
      emailFormat: 'text',
      text: expr('{{ $json.text_body }}'),
      options: {
        appendAttribution: false,
        allowUnauthorizedCerts: false,
        replyTo: 'rahulkarri@rkvaraha.com'
      }
    },
    credentials: { smtp: newCredential('RK Varaha SMTP') },
    onError: 'continueErrorOutput',
    retryOnFail: true,
    maxTries: 3,
    waitBetweenTries: 2000
  },
  output: [{ accepted: ['employee@example.com'], rejected: [], response: '250 accepted', error: { message: 'SMTP delivery failed' } }]
});

const markSent = node({
  type: 'n8n-nodes-base.supabase',
  version: 1,
  config: {
    name: 'Mark Email Sent',
    parameters: {
      resource: 'row',
      operation: 'update',
      tableId: 'notification_outbox',
      filterType: 'manual',
      matchType: 'allFilters',
      filters: { conditions: [{ keyName: 'id', condition: 'eq', keyValue: expr('{{ $("Fetch Pending Emails").item.json.id }}') }] },
      dataToSend: 'defineBelow',
      fieldsUi: { fieldValues: [
        { fieldId: 'status', fieldValue: 'sent' },
        { fieldId: 'sent_at', fieldValue: expr('{{ $now.toISO() }}') },
        { fieldId: 'attempts', fieldValue: expr('{{ $("Fetch Pending Emails").item.json.attempts + 1 }}') },
        { fieldId: 'last_error', fieldValue: '' },
        { fieldId: 'updated_at', fieldValue: expr('{{ $now.toISO() }}') }
      ] }
    },
    credentials: { supabaseApi: newCredential('RK Varaha Supabase') },
    retryOnFail: true,
    maxTries: 3,
    waitBetweenTries: 1000
  },
  output: [{ id: 1, status: 'sent', sent_at: '2026-09-19T06:00:03.000Z' }]
});

const markFailed = node({
  type: 'n8n-nodes-base.supabase',
  version: 1,
  config: {
    name: 'Mark Email Failed',
    parameters: {
      resource: 'row',
      operation: 'update',
      tableId: 'notification_outbox',
      filterType: 'manual',
      matchType: 'allFilters',
      filters: { conditions: [{ keyName: 'id', condition: 'eq', keyValue: expr('{{ $("Fetch Pending Emails").item.json.id }}') }] },
      dataToSend: 'defineBelow',
      fieldsUi: { fieldValues: [
        { fieldId: 'status', fieldValue: 'failed' },
        { fieldId: 'attempts', fieldValue: expr('{{ $("Fetch Pending Emails").item.json.attempts + 1 }}') },
        { fieldId: 'last_error', fieldValue: expr('{{ String($json.error?.message || $json.error || "SMTP delivery failed").slice(0, 500) }}') },
        { fieldId: 'updated_at', fieldValue: expr('{{ $now.toISO() }}') }
      ] }
    },
    credentials: { supabaseApi: newCredential('RK Varaha Supabase') },
    retryOnFail: true,
    maxTries: 3,
    waitBetweenTries: 1000
  },
  output: [{ id: 1, status: 'failed', last_error: 'SMTP delivery failed' }]
});

export default workflow('rkvaraha-employee-access-email-worker', 'RK Varaha — Employee Access Emails')
  .add(everyFiveMinutes)
  .to(fetchPending)
  .to(sendEmail.to(markSent).onError(markFailed));
