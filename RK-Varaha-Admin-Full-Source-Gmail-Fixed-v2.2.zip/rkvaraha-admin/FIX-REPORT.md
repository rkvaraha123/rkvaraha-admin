# Audit and responsiveness repair — 18 September 2026

## Root cause and release mismatch
The published site was still deployment 6aad0eade99a5ab838ea9503. The audit-fix archive prepared later had not replaced that release. The old modal displayed only separator dots: numeric PostgreSQL event IDs could not match strings from button data attributes.

## Changes
- Normalize IDs when finding records; missing records produce a useful message instead of an empty editor.
- Audit details show actor, action, record, date, and readable before/after values. Empty stored deltas are explicitly explained. Historical information never captured by the database cannot be reconstructed by this UI.
- Reuse membership checks for up to two minutes; Supabase RLS still checks access on every database request.
- Omit exact counts on overview previews. Keep exact counts on paginated lists.
- Update navigation without rebuilding the sidebar. Ignore stale responses after navigation or sign-out; deduplicate initial workspace entry.
- Use 15-second page-load cancellation and 20-second fetch limits. Failed background reads preserve the last successful screen with an error notice.
- Reduce background polling and avoid unnecessary refresh on short tab switches.
- Bundle the SDK locally; remove external font requests and modal backdrop blur.
- Content-hashed JS/CSS receive long-lived cache headers. HTML must revalidate, so new deployments reference fresh asset names.
- Keep the established Netlify build command and pinned package lock. Only the known public Supabase publishable key is excepted from smart secret scanning.

## Tests
20 automated tests pass. The runtime test includes numeric audit detail clicks, all navigation pages, contact editors, status filters, one membership request across navigation, delayed response isolation, and background-error preservation. Separate tests cover empty audit deltas, false/zero values, escaping, query limits, CSV protection, errors, conflict handling, and permissions in UI.

Production dependency audit: zero reported vulnerabilities.

No schema, database records, permissions, or n8n workflows were changed in this repair. Current data volume is small (one contact, one enquiry, seven audit records); speculative new indexes would not resolve the observed frontend failures. Supabase performance advisors returned informational [unused-index notices](https://supabase.com/docs/guides/database/database-linter?lint=0005_unused_index), with no performance warnings or errors. Existing indexes were retained for growing workloads.

## Limits
These checks do not establish that all future errors are impossible. Real hundreds-of-users load testing, mobile/device testing, and email delivery verification remain separate rollout checks. No speedup percentage is claimed without a controlled benchmark. The 200-client test uses simulated queries, not production traffic.

## Deployment
For Git-based deployment: npm ci, npm test, npm run build; Netlify publishes dist.
Deploy through the configured Netlify build or run the Netlify CLI from this repository root after building. Do not publish public/ directly: public/app.js has a bare SDK import and requires bundling. Retain netlify.toml for the cache and security headers.

## Published verification
Deployment 6aad5280563b510ed4214050 is ready and live. The original blank audit dialog was reproduced before publishing; the same real event displayed its actor, action, record, time, and status afterwards. An empty-delta update also displayed its explanation correctly. All eleven authenticated sections loaded, contact/enquiry editors opened, and the team approval list loaded. No business records were modified during these browser checks.

One warm browser pass measured about 0.28–0.49 seconds from navigation action through the main data screen appearing (My account about 0.11 seconds). This includes automation overhead, uses a tiny current dataset, excludes cold sign-in and secondary loads such as approvals, and is not a device or concurrency benchmark.

The published JavaScript SHA-256 matched the local tested asset exactly. Live HTML headers require revalidation; hashed assets use a one-year immutable cache policy. The desktop audit dialog was visually inspected. The browser log entries observed were extension metadata errors, not application errors.
