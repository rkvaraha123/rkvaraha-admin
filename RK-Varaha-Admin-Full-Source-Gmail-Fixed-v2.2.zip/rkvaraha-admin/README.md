# RK Varaha Workspace · v2.2

Live dashboard: https://admin.rkvaraha.com/

Sign in using the existing company owner account. Business data is stored in the existing Supabase project. This release preserves the original contact, enquiry, appointment, and workflow tables.

## Included

- Overview with whole-dataset counts, 14-day enquiry activity, source totals, pipeline and upcoming meetings.
- Contacts: search, pagination, creation, editing, ownership, six lead stages, recent activity and notes.
- Enquiries: full customer messages, contact details, service, source, status and priority.
- Pipeline: searchable stage views, including Lost, with contact editing.
- Tasks: owner, project, related contact, priority, due time, status and blockers.
- Projects: brief, owner, due date and status.
- Appointments: upcoming/past/all views, contact, start/end, meeting link, notes and outcomes.
- Automation monitor: existing n8n database synchronization records with error details.
- Team: paginated directory, email preapproval, role assignment, department and suspension.
- Append-only audit history for business record changes and membership changes.
- Google sign-in through Supabase Auth, plus email/password fallback.
- Owner/admin Gmail mailbox connection with inbox search, message reading and plain-text sending.
- Authenticated Netlify Gmail Functions with encrypted, per-admin refresh-token storage.
- Secure employee invitation emails, tracked acceptance, password recovery, password changes and email-change confirmations.
- n8n employee-access email worker with a private Supabase outbox and delivery status tracking.
- CSV exports across pages; spreadsheet formula protection.
- Optimistic conflict checks on edited business records; database-enforced permissions.
- Responsive layout, keyboard labels, native modal focus handling, loading, empty, offline and error states.

## Employee onboarding

1. An owner/admin opens Team & access → Invite employee.
2. Enter the employee's name, email, department and role. The invitation lasts seven days.
3. Supabase sends the secure invitation email. The employee can accept it or use Google with the same approved email.
4. The dashboard records invitation delivery state and acceptance.
5. Managers assign contacts and tasks. Employees can access only their permitted work.

| Role | Business data | Team management | Audit history |
|---|---|---|---|
| Owner | Company-wide read/write | Yes; owner account protected | Yes |
| Admin | Company-wide read/write | Yes; cannot edit the owner or self | Yes |
| Manager | Company-wide read/write | Directory only | No |
| Employee | Assigned contacts, enquiries, meetings, tasks and related projects | No | No |
| Viewer | Company-wide read-only | No | No |

Suspension is checked by database policies on every request. Owner/admin access is powerful; do not give it to ordinary employees. This release does not partition managers into departments: department is directory metadata.

## Development and deployment

```bash
npm ci
npm test
npm run build
npm start
```

`public/` contains source assets, `dist/` is generated and served. The build bundles the pinned Supabase SDK locally, so the app does not import executable JavaScript from a CDN at runtime. Netlify publishes only `dist`, not SQL, tests, or source documentation.

Netlify settings: build `npm run build`, publish `dist`, Node 22. `netlify.toml` contains the settings and response headers. Link the GitHub repository to the existing Netlify project for automatic deployments after future commits.

Gmail requires a full repository deployment because its API routes live in `netlify/functions`. Do not deploy a ZIP containing only the generated `dist` folder. Follow `GMAIL-SETUP.md`, rotate the previously exposed Google secret, and add the private values in Netlify's environment settings.

The current ChatGPT GitHub connection reports read-only permission, so the modified source has not been pushed to GitHub. The supplied release ZIP contains the complete updated source and built assets. Replace the old repository contents with this source (excluding `dist` if using the included `.gitignore`) when write access is available, then deploy it to the existing `rkvaraha-admin` Netlify project.

## Database

The upgrades have already been applied to project `puishgbbxlxatkjejfke`.

- `database/upgrade.sql`: schema, policies, access management and aggregate metrics.
- `database/ingestion-concurrency.sql`: transaction locks for concurrent matching enquiries and idempotent retries.
- `database/verify-access.sql`: transactional access tests with automatically rolled-back fixtures.
- `database/summary.sql`: current optimized metrics function, also included in the upgrade.
- `database/auth-and-notifications.sql`: invitation tracking, auth provisioning, onboarding completion and the private notification outbox.

The Supabase Edge Function `team-invite` is deployed with JWT verification enabled. The n8n workflow `RK Varaha — Employee Access Emails` is published in the personal project and processes the outbox every five minutes.

Read `GOOGLE-AUTH-SETUP.md` before enabling Google in production. Google login remains unavailable until the provider is enabled in Supabase with a newly rotated client secret.

These scripts upgrade this existing RK Varaha schema; they are not a generic bootstrap for an empty database. Review against the target schema before applying anywhere else. Do not run access tests on another production database without reviewing their fixture assumptions.

## Operational limits

- Lists load 25 rows at a time. Lookup fields return 50 matches and support narrowing the name. Recent contact activity shows the latest 50 entries; recent onboarding approvals show the latest 100.
- CSV export is capped at 100,000 matching rows and reports an error if exceeded. Exports are successive live reads, not a transactionally frozen database snapshot; avoid heavy concurrent editing during exports.
- Background refresh runs about every 90–110 seconds on Overview and 180–200 seconds on lists while the tab is visible and no form is being edited. It is polling, not streaming realtime.
- n8n is used for background ingestion/synchronization; it is not in the path of every employee's dashboard read.
- Automation success here means the database-sync step succeeded. It does not prove SMTP delivery or HubSpot sync.
- Standard email/password auth is used; enterprise SSO and enforced MFA are not implemented in this release.
- Password recovery and new-employee verification require correct Supabase Auth redirect URLs and working email delivery. Those delivery flows still require a live user test; the existing owner sign-in and task save/update flows were verified.

Read `TESTING.md` before a broad employee rollout. Hundreds of simultaneous employee sessions have not been load-certified. Use a staging environment and realistic dataset to measure latency, error rate, Auth limits, connection usage and provider quotas before rollout. Keep tested database backups and a restore procedure.
